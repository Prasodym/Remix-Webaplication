<?php $var = $server->online; //$server->online returns true if the server is online, and false otherwise
       //Outputs the maximum number of players the server allows

      echo "<div id='checks'>". $server->online_players ." Spieler von " . $server->max_players . " sind Online</div>";
////// Oben sind die spieleranzahl die gerade online sind?>

<?php
$ip = "78.46.71.248";
$port = "25565";
if (!@$fp = fsockopen($ip, $port, $errno, $errstr, 1)){
echo "<div class='server_o' style='margin-top: 0px;
'>Online</div>";
} else {
echo "<div class='server_of'>Offline</div>";
}
?>
<!-- Player list ##################### -->
<script>
$.getJSON('https://api.mcsrvstat.us/2/jomlua.de:25566', function(status) {
//Show the version
console.log(status.version);

//Show a list of players
$.each(status.players.list, function(index, player){
console.log(player);
});
});
</script>
<?php
//Get the status and decode the JSON
$status = json_decode(file_get_contents('https://api.mcsrvstat.us/2/jomlua.de:25566'));

//Show the version


//Show a list of players
foreach ($status->players->list as $player) {
echo "<div class='server_p'>";
echo "<img id='s2' style='width: 24px;' src='https://minecraft-statistic.net/face/". $player .".png' alt='". $player ."'>";
echo "<p id='s1'>  " . $player . "</p>";
echo "</div>";
}
?>

<!-- Player list end   https://minecraft-statistic.net/face/Prasodym.png-->
