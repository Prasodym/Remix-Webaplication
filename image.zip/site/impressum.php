<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <?php include("../css/inter.html"); ?>
    <link rel="stylesheet" href="../css/pop.css">
    <meta charset="utf-8">
    <title>Impressum</title>
  </head>
  <body>
    <div class="content">
      <h3>Impressum</h3>
      <p><b>Angaben nach §5 TMG</b></p>
      <table class="table table-dark">
  <thead>
    <tr>

      <th scope="col">Tobias</th>
      <th scope="col">Bieder</th>

    </tr>
  </thead>
  <tbody>
    <tr>

      <td>Altlandsberger Chaussee</td>
      <td>28</td>

    </tr>
    <tr>

      <td>15370</td>
      <td>Fredersdorf-Vogelsdorf</td>

    </tr>
    <tr>

      <td>Brandenburg</td>
      <td>Germany</td>

    </tr>
    <tr>
      <td>info@jomlua.de</td>
      <td></td>
    </tr>
  </tbody>
</table>
    </div>
  </body>
</html>
