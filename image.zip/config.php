<?php

//Mysql Verbindung = Änder diese wenn es auf ein Fremden Server läuft.
$db_host="localhost";
$db_user="root";
$db_password="";
$db_database="test";
//Index.php Configation.

$web_title="Space Remix Servertool";
$web_charset="utf-8";

//Navigation default Home | Vote | Discord | Contact
$navigation_site1=" Startseite";
$navigation_site2=" Vote";
$navigation_site3=" Discord Server";
$navigation_site4=" Kontakt";



 ?>
